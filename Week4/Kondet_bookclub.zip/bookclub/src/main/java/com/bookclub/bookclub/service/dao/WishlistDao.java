package com.bookclub.bookclub.service.dao;

import com.bookclub.bookclub.model.WishlistItem;
import com.bookclub.bookclub.service.GenericDao;

public interface WishlistDao extends GenericDao<WishlistItem, String> {
}
